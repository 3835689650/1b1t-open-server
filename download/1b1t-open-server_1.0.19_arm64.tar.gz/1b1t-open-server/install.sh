#!/bin/bash
set -e
D=/usr/local/bin
if [ ! -w "$D" ]; then sudo mkdir -p "$D"; sudo cp 1b1t "$D/1b1t"; sudo chmod +x "$D/1b1t"
else cp 1b1t "$D/1b1t"; chmod +x "$D/1b1t"; fi
echo "安装完成! 终端输入 1b1t 启动"

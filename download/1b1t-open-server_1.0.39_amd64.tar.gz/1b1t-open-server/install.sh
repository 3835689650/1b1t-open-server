#!/bin/bash
# 1b1t 一键安装 (amd64 独立版, 免 Python)
set -e
D=/usr/local/bin
if [ ! -w "$D" ]; then sudo mkdir -p "$D"; sudo cp 1b1t "$D/1b1t"; sudo chmod +x "$D/1b1t"
else cp 1b1t "$D/1b1t"; chmod +x "$D/1b1t"; fi
echo "安装完成! 重新打开终端, 输入 1b1t 即可启动"

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1b1t-open-server — Minecraft 一键开服工具

向导流程: ①选择版本 ②选择目录 ③选择端口 ④常见配置(正版验证/命令方块/死亡不掉落等)
          ⑤高级选项(编辑 server.properties 全部项) → 自动下载核心并开服
子命令:   start [目录] | stop [目录] | restart [目录] | status [目录] | console <目录> <命令>
"""

import json
import os
import re
import select
import shlex
import shutil
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

# 本地安装包镜像目录 (下载过的文件缓存到这里, 下次直接从本地取)
MIRROR_DIR = os.path.expanduser("~/1b1t-mirror")
# 镜像的 HTTP 出口 (www.1b1t.cn/serverdown, 其他机器走隧道下载)
MIRROR_HTTP = "https://www.1b1t.cn/serverdown/"
# 软件设置文件 (settings 子命令修改)
SETTINGS_FILE = os.path.expanduser("~/.config/1b1t-open-server/settings.json")
SETTING_DEFAULTS = {
    "online_mode": "true", "difficulty": "normal", "motd": "1b1t Server",
    "keep_inventory": "false", "mirror_dir": "", "mirror_http": "",
}


def load_settings():
    try:
        with open(SETTINGS_FILE) as f:
            s = json.load(f)
        d = dict(SETTING_DEFAULTS)
        d.update(s)
        return d
    except (OSError, ValueError):
        return dict(SETTING_DEFAULTS)


def save_settings(s):
    os.makedirs(os.path.dirname(SETTINGS_FILE), exist_ok=True)
    with open(SETTINGS_FILE, "w") as f:
        json.dump(s, f, ensure_ascii=False, indent=2)


def mirror_dir():
    """镜像目录 (可在软件设置里改)"""
    st = load_settings()
    return os.path.expanduser(st.get("mirror_dir") or MIRROR_DIR)


def mirror_http():
    st = load_settings()
    return st.get("mirror_http") or MIRROR_HTTP

APP = "1b1t-open-server"
CACHE_DIR = os.path.expanduser("~/.cache/1b1t-open-server")
MANIFEST_URL = "https://bmclapi2.bangbang93.com/mc/game/version_manifest_v2.json"
BMCL_VERSION = "https://bmclapi2.bangbang93.com/version/{vid}/json"
BMCL_SERVER_JAR = "https://bmclapi2.bangbang93.com/version/{vid}/server"
RUNTIME_DIR = ".1b1t-open-server"      # 服务器目录下: pid/config/console.log
IS_WIN = (os.name == "nt")

# stop 后后台收尾进程: 等服务器退出 → 必要时强杀进程组 → 杀 keeper → 删 pid.json
# (attach 里输 stop 后工具立即退出, 收尾交给这个分离进程, 保证关得干净)
CLEANUP_CODE = r"""
import json, os, signal, sys, time
server_dir = sys.argv[1]
rt = os.path.join(server_dir, ".1b1t-open-server")

def is_running(pid):
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False

def load_pid():
    try:
        with open(os.path.join(rt, "pid.json")) as f:
            return json.load(f)
    except Exception:
        return None

for _ in range(240):  # 最多等 4 分钟
    info = load_pid()
    if not info or not is_running(info["pid"]):
        break
    time.sleep(1)
info = load_pid()
if info and is_running(info["pid"]):  # 还没退, 强杀整个进程组
    try:
        os.killpg(info["pid"], 9)
    except (OSError, AttributeError):
        try:
            os.kill(info["pid"], 9)
        except OSError:
            pass
    time.sleep(2)
if info:
    keeper = info.get("keeper")
    if keeper and is_running(keeper):
        try:
            os.kill(keeper, signal.SIGTERM)
        except OSError:
            pass
try:
    os.remove(os.path.join(rt, "pid.json"))
except OSError:
    pass
"""

# 控制台 keeper: 持有 java stdin 写端, 监听本地 TCP 转发命令 (Linux/Windows/macOS 通用)
# 注意: fd0 是管道写端(O_WRONLY), sys.stdin 会初始化失败, 必须用 os.write(0, ...)
KEEPER_CODE = r"""
import os, select, socket, sys
srv = socket.socket()
srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
srv.bind(("127.0.0.1", int(sys.argv[1])))
srv.listen(4)
try:  # Linux/macOS: poll 管道写端, java 退出(读端关闭)时 POLLERR 触发自杀
    poller = select.poll()
    poller.register(0, select.POLLERR | select.POLLHUP)
except (AttributeError, OSError):
    poller = None
while True:
    r, _, _ = select.select([srv], [], [], 0.2)
    if poller is not None:
        for _fd, ev in poller.poll(0):
            if ev & (select.POLLERR | select.POLLHUP):
                sys.exit(0)  # java 已退出, 管道断裂
    if not r:
        continue
    c, _ = srv.accept()
    data = c.recv(65536).decode("utf-8", "ignore")
    c.close()
    for line in data.splitlines():
        try:
            os.write(0, (line + "\n").encode())
        except OSError:
            sys.exit(0)  # java 已退出, 管道断裂
"""

# 启动横幅 (figlet standard 字体)
BANNER = r"""
 _  _      _  _
/ || |__  / || |_    ___   _ __    ___  _ __          ___   ___  _ __ __   __ ___  _ __
| || '_ \ | || __|  / _ \ | '_ \  / _ \| '_ \  _____ / __| / _ \| '__|\ \ / // _ \| '__|
| || |_) || || |_  | (_) || |_) ||  __/| | | ||_____|\__ \|  __/| |    \ V /|  __/| |
|_||_.__/ |_| \__|  \___/ | .__/  \___||_| |_|       |___/ \___||_|     \_/  \___||_|
                          |_|
"""

# 版本 → 所需 Java 主版本 (>= 指该版本起)
JAVA_RULES = [
    ((1, 0, 0), (1, 16, 5), 8),
    ((1, 17, 0), (1, 17, 1), 16),
    ((1, 18, 0), (1, 20, 4), 17),
    ((1, 20, 5), (99, 0, 0), 21),
]

# 网络失败时的兜底版本列表
FALLBACK_VERSIONS = ["1.8.8", "1.12.2", "1.14.4", "1.16.5", "1.17.1", "1.18.2",
                     "1.19.4", "1.20.1", "1.20.4", "1.20.6", "1.21", "1.21.1", "1.21.4"]

# server.properties 全部键: (key, 默认值, 中文说明)
PROPS = [
    ("server-port", "25565", "服务器端口"),
    ("server-ip", "", "监听地址(空=全部)"),
    ("motd", "1b1t Server", "服务器列表显示的名称"),
    ("max-players", "20", "最大玩家数"),
    ("online-mode", "true", "正版验证"),
    ("white-list", "false", "白名单"),
    ("enforce-whitelist", "false", "强制白名单(踢出不在名单的在线玩家)"),
    ("pvp", "true", "玩家对战"),
    ("difficulty", "normal", "难度 peaceful/easy/normal/hard"),
    ("hardcore", "false", "极限模式"),
    ("gamemode", "survival", "默认游戏模式"),
    ("force-gamemode", "false", "强制默认游戏模式"),
    ("allow-flight", "false", "允许飞行"),
    ("allow-nether", "true", "允许下界"),
    ("view-distance", "10", "视距"),
    ("simulation-distance", "10", "模拟距离"),
    ("spawn-protection", "16", "出生点保护半径(0=关闭)"),
    ("spawn-animals", "true", "生成动物"),
    ("spawn-monsters", "true", "生成怪物"),
    ("spawn-npcs", "true", "生成村民"),
    ("generate-structures", "true", "生成结构(村庄/神殿等)"),
    ("level-name", "world", "世界文件夹名"),
    ("level-seed", "", "种子(空=随机)"),
    ("level-type", "minecraft\\:normal", "世界类型 normal/flat/largebiomes"),
    ("generator-settings", "{}", "超平坦自定义"),
    ("max-world-size", "29999984", "世界边界半径"),
    ("max-tick-time", "60000", "单 tick 超时毫秒(-1=禁用崩溃检测)"),
    ("max-chained-neighbor-updates", "1000000", "连锁方块更新上限"),
    ("sync-chunk-writes", "true", "同步写区块(true=防损坏 false=性能好)"),
    ("player-idle-timeout", "0", "挂机踢出分钟数(0=关闭)"),
    ("rate-limit", "0", "发包速率限制"),
    ("network-compression-threshold", "256", "网络压缩阈值"),
    ("use-native-transport", "true", "使用 epoll 网络传输"),
    ("prevent-proxy-connections", "false", "防代理(需正版)"),
    ("enforce-secure-profile", "true", "强制安全聊天签名"),
    ("log-ips", "true", "日志记录玩家 IP"),
    ("hide-online-players", "false", "隐藏在线人数"),
    ("enable-command-block", "false", "命令方块"),
    ("enable-jmx-monitoring", "false", "JMX 监控"),
    ("enable-query", "false", "GameSpy4 查询"),
    ("query.port", "25565", "查询端口"),
    ("enable-rcon", "false", "RCON 远程控制台"),
    ("rcon.port", "25575", "RCON 端口"),
    ("rcon.password", "", "RCON 密码"),
    ("broadcast-console-to-ops", "true", "控制台消息发给 OP"),
    ("broadcast-rcon-to-ops", "true", "RCON 消息发给 OP"),
    ("op-permission-level", "4", "OP 权限等级"),
    ("function-permission-level", "2", "函数权限等级"),
    ("enable-status", "true", "服务器列表在线状态"),
    ("require-resource-pack", "false", "强制资源包"),
    ("resource-pack", "", "资源包地址"),
    ("resource-pack-prompt", "", "资源包提示"),
    ("resource-pack-sha1", "", "资源包校验"),
    ("resource-pack-id", "", "资源包 UUID"),
    ("initial-enabled-packs", "vanilla", "初始启用的数据包"),
    ("initial-disabled-packs", "", "初始禁用的数据包"),
    ("text-filtering-config", "", "聊天过滤配置"),
    ("entity-broadcast-range-percentage", "100", "实体广播距离百分比"),
]


# ---------- 基础工具 ----------

def c(text, color="0"):
    """着色输出"""
    codes = {"red": "31", "green": "32", "yellow": "33", "blue": "34",
             "cyan": "36", "bold": "1", "dim": "2"}
    if not sys.stdout.isatty():
        return text
    return f"\033[{codes.get(color, '0')}m{text}\033[0m"


def ask(prompt, default=""):
    """带默认值的输入, 回车=默认"""
    tip = f" [{c(default, 'cyan')}]" if default != "" else ""
    ans = input(f"{prompt}{tip}: ").strip()
    return ans if ans != "" else default


def ask_bool(prompt, default=True):
    d = "y" if default else "n"
    while True:
        ans = ask(f"{prompt} (y/n)", d).lower()
        if ans in ("y", "yes", "true"):
            return True
        if ans in ("n", "no", "false"):
            return False
        print(c("  请输入 y 或 n", "red"))


def step(n, title):
    print(f"\n{c(f'[{n}]', 'cyan')} {c(title, 'bold')}")


def quit_ans(ans):
    """输入 0/q 退出"""
    if ans.strip() in ("0", "q", "quit", "exit"):
        sys.exit(c("已退出", "yellow"))


def vkey(ver):
    """版本号 → 可比较元组, 如 1.21.1 → (1,21,1)"""
    return tuple(int(x) for x in re.findall(r"\d+", ver)[:3] + [0, 0, 0])


def java_major_for(version):
    """根据 MC 版本返回所需 Java 主版本"""
    v = vkey(version)
    for lo, hi, major in JAVA_RULES:
        if lo <= v <= hi:
            return major
    return 21


# ---------- 版本清单 ----------

def load_manifest(force=False):
    """拉取版本清单(BMCLAPI), 24h 缓存, 失败用内置列表"""
    os.makedirs(CACHE_DIR, exist_ok=True)
    cache = os.path.join(CACHE_DIR, "versions.json")
    if not force and os.path.exists(cache):
        try:
            with open(cache) as f:
                data = json.load(f)
            if time.time() - data.get("ts", 0) < 86400:
                return data["versions"]
        except (OSError, ValueError):
            pass
    try:
        req = urllib.request.Request(MANIFEST_URL, headers={"User-Agent": APP})
        with urllib.request.urlopen(req, timeout=20) as r:
            data = json.loads(r.read().decode())
        versions = [{"id": v["id"], "type": v["type"], "url": v["url"]}
                    for v in data["versions"]]
        with open(cache, "w") as f:
            json.dump({"ts": time.time(), "versions": versions}, f)
        return versions
    except Exception as e:
        print(c(f"  在线清单获取失败({e}), 使用内置列表", "yellow"))
        return [{"id": v, "type": "release", "url": ""} for v in FALLBACK_VERSIONS]


# 版本特性参考: (版本范围, 优点, 缺点, 最低配置)
VERSION_INFO = [
    ("1.8.x", "经典PvP手感 插件生态最大 配置要求极低", "内容老 安全性较差(需防假人)", "1核/2G/10G"),
    ("1.12.x", "mod生态最大最成熟 配置低", "内容旧(无1.13海洋更新)", "2核/3G/20G"),
    ("1.16.x", "下界更新 mod双平台生态全", "资源占用较1.12明显提高", "2核/4G/30G"),
    ("1.17-1.19", "洞穴悬崖更新 内容新 活跃", "1.18起世界高度翻倍吃内存", "2核/4-6G/40G"),
    ("1.20.x", "社区活跃 插件/mod支持全", "1.20.5+必须Java21", "4核/6G/50G"),
    ("1.21.x+", "最新内容 长期更新", "最吃资源 部分老插件未适配", "4核/8G/60G"),
]


def dw(s):
    """字符串显示宽度(中日韩字符算2)"""
    return sum(2 if ord(ch) > 0x2E80 else 1 for ch in s)


def print_table(rows, indent="  "):
    """打印表格, rows 首行为表头 (自动处理中文宽度)"""
    widths = [max(dw(str(r[i])) for r in rows) + 2 for i in range(len(rows[0]))]
    line = indent + "+" + "+".join("-" * w for w in widths) + "+"
    print(line)
    for i, r in enumerate(rows):
        print(indent + "|" + "|".join(
            " " + str(r[j]) + " " * (widths[j] - dw(str(r[j])) - 1)
            for j in range(len(r))) + "|")
        if i == 0:
            print(line)
    print(line)


def version_table():
    """打印版本优点/缺点/最低配置表格"""
    print_table([("版本", "优点", "缺点", "最低配置")] + [list(r) for r in VERSION_INFO])


def pick_version():
    """① 选择版本: 版本特性表格 + 最近正式版列表, 也可直接输入任意版本号"""
    step(1, "选择 Minecraft 版本")
    print(c("  版本特性参考:", "cyan"))
    version_table()
    versions = load_manifest()
    releases = [v for v in versions if v["type"] == "release"]
    by_id = {v["id"]: v for v in versions}
    print(c("  最近正式版:", "cyan"))
    for i, v in enumerate(releases[:15]):
        print(f"    {i+1:>2}. {v['id']}")
    print(f"    也可以直接输入任意版本号(含快照), 如 {c('1.8.8', 'cyan')}")
    print(f"    {c('0 退出', 'dim')}")
    while True:
        ans = ask("  输入序号或版本号").strip()
        quit_ans(ans)
        if ans.isdigit() and 1 <= int(ans) <= len(releases[:15]):
            return releases[int(ans) - 1]
        if ans in by_id:
            return by_id[ans]
        print(c("  无效输入", "red"))


# ---------- Java ----------

def _java_major(java_bin):
    try:
        out = subprocess.run([java_bin, "-version"], capture_output=True,
                             text=True, timeout=10).stderr.splitlines()[0]
        m = re.search(r'version "(\d+)(?:\.(\d+))?', out)
        if m:
            return int(m.group(1)) if m.group(1) != "1" else int(m.group(2))
    except Exception:
        pass
    return None


def detect_javas():
    """扫描系统已装 Java (Linux/Windows/macOS), 返回 {主版本: [bin路径]}"""
    found = {}
    cands = set()
    exe = "java.exe" if IS_WIN else "java"
    jh = os.environ.get("JAVA_HOME")
    if jh:
        cands.add(os.path.join(jh, "bin", exe))
    for p in shlex.split(os.environ.get("PATH", "")):
        cands.add(os.path.join(p, exe))
    if IS_WIN:
        # Windows: 常见 JDK 安装目录
        pf = [os.environ.get("ProgramFiles", r"C:\Program Files"),
              os.environ.get("ProgramFiles(x86)", ""),
              os.environ.get("ProgramW6432", "")]
        for root in pf:
            for sub in ("Java", "Eclipse Adoptium", "Microsoft", "Zulu",
                        "Amazon Corretto", "BellSoft", "Semeru"):
                d = os.path.join(root, sub)
                if os.path.isdir(d):
                    for entry in os.listdir(d):
                        cands.add(os.path.join(d, entry, "bin", exe))
    else:
        roots = ["/usr/lib/jvm", "/opt/java", "/usr/java",
                 os.path.expanduser("~/.jdks"), os.path.expanduser("~/sdkman")]
        if sys.platform == "darwin":  # macOS
            roots += ["/Library/Java/JavaVirtualMachines",
                      "/System/Library/Java/JavaVirtualMachines"]
            # 优先用系统接口查所有 JDK
            try:
                out = subprocess.run(["/usr/libexec/java_home", "-V"],
                                     capture_output=True, text=True, timeout=10).stderr
                for p in re.findall(r'^\s+(\S+)', out, re.M):
                    cands.add(os.path.join(p, "Contents", "Home", "bin", "java"))
            except Exception:
                pass
        for root in roots:
            if os.path.isdir(root):
                for entry in os.listdir(root):
                    for cand in (os.path.join(root, entry, "bin", "java"),
                                 os.path.join(root, entry, "Contents", "Home",
                                              "bin", "java")):  # macOS 包结构
                        cands.add(cand)
    for p in sorted(cands):
        if not os.path.isfile(p):
            continue
        p = os.path.realpath(p)
        major = _java_major(p)
        if major and p not in found.setdefault(major, []):
            found[major].append(p)
    return found


def java_install_hint(need):
    """各平台安装 JDK 的提示"""
    if IS_WIN:
        return f"下载 JDK {need} 安装包: https://adoptium.net/zh-CN/temurin/"
    if sys.platform == "darwin":
        return f"brew install openjdk@{need}"
    return f"apt install openjdk-{need}-jdk"


def auto_install_java(need):
    """自动安装缺失的 JDK, 成功返回 java 路径, 失败返回 None"""
    print(c(f"  未找到 Java {need}, 尝试自动安装...", "yellow"))
    try:
        if IS_WIN:
            print(c(f"  Windows 请手动下载安装 (装完重开本工具即可): "
                    f"https://adoptium.net/zh-CN/temurin/ (JDK {need})", "yellow"))
            return None
        if sys.platform == "darwin":
            if shutil.which("brew"):
                print("  执行: brew install openjdk@" + str(need))
                subprocess.run(["brew", "install", f"openjdk@{need}"])
            else:
                print(c("  未找到 Homebrew, 请先装: https://brew.sh/", "red"))
                return None
        else:
            # Linux: 按发行版选包管理器
            pms = (("apt", ["sudo", "apt", "install", "-y", f"openjdk-{need}-jdk"]),
                   ("dnf", ["sudo", "dnf", "install", "-y", f"java-{need}-openjdk"]),
                   ("pacman", ["sudo", "pacman", "-S", "--noconfirm", f"jdk{need}-openjdk"]))
            ran = False
            for pm, cmd in pms:
                if shutil.which(pm):
                    print(f"  执行: {' '.join(cmd)}")
                    subprocess.run(cmd)
                    ran = True
                    break
            if not ran:
                print(c(f"  未找到 apt/dnf/pacman, 请手动安装: {java_install_hint(need)}", "red"))
                return None
        javas = detect_javas()
        if need in javas:
            print(c(f"  安装成功: {javas[need][0]}", "green"))
            return javas[need][0]
    except Exception as e:
        print(c(f"  自动安装失败: {e}", "red"))
    return None


def pick_java(version, java_major=None):
    """为 MC 版本找匹配的 Java (优先官方 javaVersion 字段), 缺则自动安装"""
    need = java_major or java_major_for(version)
    javas = detect_javas()
    if need in javas:
        return javas[need][0]
    got = "、".join(f"Java{k}" for k in sorted(javas)) or "无"
    print(c(f"\n[提示] {version} 需要 Java {need}, 本机只有: {got}", "yellow"))
    if sys.stdin.isatty() and ask_bool(f"  自动安装 Java {need}?", True):
        java = auto_install_java(need)
        if java:
            return java
    sys.exit(c(f"[错误] 缺少 Java {need}, 请手动安装: {java_install_hint(need)}", "red"))


# ---------- server.properties ----------

def render_properties(props):
    """props: {key: value}, 按 PROPS 顺序带中文注释输出"""
    lines = [f"# 由 {APP} 生成 {time.strftime('%Y-%m-%d %H:%M')}",
             "# 修改后可用: 1b1t-open-server start <目录> 重新开服"]
    for key, default, desc in PROPS:
        val = props.get(key, default)
        lines.append(f"\n# {desc}")
        lines.append(f"{key}={val}")
    return "\n".join(lines) + "\n"


def advanced_editor(props):
    """⑤ 高级选项: 列出全部项, 输入 '编号 值' 修改, 输入 done 结束"""
    step(5, "高级选项 (编辑 server.properties 全部项)")
    if not ask_bool("  要进入高级选项吗?", False):
        return props
    while True:
        print()
        for i, (key, default, desc) in enumerate(PROPS):
            val = props.get(key, default)
            print(f"  {c(str(i+1).rjust(2), 'cyan')}. {key:<38} = {c(val, 'green'):<20} {desc}")
        print(c("  用法: 输入 '编号 值' 修改该项, 回车/done 结束", "yellow"))
        ans = ask("  修改").strip()
        if ans in ("", "done", "q"):
            return props
        m = re.match(r"(\d+)\s+(.*)", ans)
        if m:
            i = int(m.group(1)) - 1
            if 0 <= i < len(PROPS):
                props[PROPS[i][0]] = m.group(2).strip()
                print(c(f"  已设置 {PROPS[i][0]} = {m.group(2).strip()}", "green"))
                continue
        print(c("  格式错误, 例如: 3 25567 或 12 hard", "red"))


# ---------- 下载 ----------

def _sha1(path):
    import hashlib
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _mirror_path(url):
    """URL → 本地镜像文件路径 (域名/路径 结构)"""
    p = urllib.parse.urlparse(url)
    return os.path.join(mirror_dir(), p.netloc, p.path.lstrip("/"))


def _fetch_one(url, dest, expect_sha1=None, expect_size=None, quiet=False):
    """单个 URL 下载, 显示进度, 支持续传, 失败返回 False"""
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    headers = {"User-Agent": APP}
    have = os.path.getsize(dest) if os.path.exists(dest) else 0
    if have:
        headers["Range"] = f"bytes={have}-"
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=60) as r:
            if not quiet:
                print(c(f"  下载源: {url}", "dim"))
            total = int(r.headers.get("Content-Length", 0)) + have
            mode = "ab" if have else "wb"
            with open(dest, mode) as f:
                while True:
                    chunk = r.read(1 << 20)
                    if not chunk:
                        break
                    f.write(chunk)
                    if not quiet:
                        done = f.tell()
                        pct = done * 100 // total if total else 0
                        print(f"\r  下载中 {done>>20}MB"
                              + (f"/{total>>20}MB {pct}%" if total else ""),
                              end="", flush=True)
            if not quiet:
                print()
    except urllib.error.HTTPError as e:
        if e.code == 416 and have:
            # Range 起点超出文件末尾 = 文件已下载完整
            if not quiet:
                print(c("  文件已完整, 跳过下载", "green"))
            return True
        if not quiet:
            print(c(f"  下载失败({e.code}): {url}", "red"))
        return False
    except Exception as e:
        if not quiet:
            print(c(f"  下载失败({e}): {url}", "red"))
        return False
    if expect_sha1 and _sha1(dest) != expect_sha1:
        if not quiet:
            print(c("  SHA1 校验失败, 文件可能损坏", "red"))
        return False
    return True


def fetch(url, dest, expect_sha1=None, expect_size=None):
    """下载文件: 本地镜像优先 → 多源依次尝试 → 成功后缓存到镜像"""
    urls = url if isinstance(url, (list, tuple)) else [url]
    # 1. 本地镜像命中直接复制
    for u in urls:
        mp = _mirror_path(u)
        if os.path.exists(mp) and os.path.getsize(mp) > 0:
            if expect_size and os.path.getsize(mp) != expect_size:
                continue
            if expect_sha1 and _sha1(mp) != expect_sha1:
                continue
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(mp, dest)
            print(c(f"  本地镜像命中: {os.path.basename(dest)}", "green"))
            return True
    # 2. 网络下载: 自动切换源
    # 本机文件镜像与 serverdown 是同一份数据(bind mount), 文件未命中则 serverdown 也没有,
    # 直接走官方源; 其他机器(无本机镜像目录)先试 serverdown 隧道镜像
    # 注意 serverdown 路径必须含域名段(与镜像物理结构一致), 否则永远 404
    if os.path.isdir(mirror_dir()):
        net_urls = list(urls)
    else:
        net_urls = [mirror_http() + os.path.relpath(_mirror_path(u), mirror_dir())
                    for u in urls] + list(urls)
    for u in net_urls:
        if _fetch_one(u, dest, expect_sha1, expect_size):
            # 3. 缓存到本地镜像, 下次秒取
            try:
                os.makedirs(os.path.dirname(_mirror_path(u)), exist_ok=True)
                shutil.copy2(dest, _mirror_path(u))
                print(c("  已缓存到本地镜像", "cyan"))
            except OSError:
                pass
            return True
    return False


# mod 服务器: Fabric/NeoForge/Forge 元数据源
FABRIC_META = "https://bmclapi2.bangbang93.com/fabric-meta/v2/versions/loader/{mc}"
NEOFORGE_META = "https://maven.neoforged.net/releases/net/neoforged/neoforge/maven-metadata.xml"
FORGE_META = "https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml"

_VERSION_INFO_CACHE = {}


def http_get(url, timeout=30, retries=3):
    """GET 返回文本, 失败自动重试"""
    last = None
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": APP})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read().decode()
        except Exception as e:
            last = e
            time.sleep(1 + i)
    raise last


def http_json(url, timeout=30):
    return json.loads(http_get(url, timeout))


def pick_server_type():
    """选择服务器类型: Vanilla/Fabric/NeoForge/Forge"""
    print(c("  服务器类型:", "cyan"))
    print_table([
        ("编号", "类型", "说明"),
        ("1", "Vanilla", "原版纯净, 无 mod"),
        ("2", "Fabric", "轻量 mod 平台, 版本覆盖最广"),
        ("3", "NeoForge", "1.20.1+ 主流 mod 平台"),
        ("4", "Forge", "老牌 mod 平台, 1.20.1 及以下最成熟"),
    ])
    print(f"    {c('0 退出', 'dim')}")
    ans = ask("  选择", "1")
    quit_ans(ans)
    return {"1": "vanilla", "2": "fabric", "3": "neoforge", "4": "forge"}.get(ans, "vanilla")


def pick_mod_version(mc_ver, stype):
    """列出该 MC 版本可用的 mod 加载器版本 (最新在前), 数字选择或直接输入"""
    print(c(f"  可用 {stype} 版本 (最新在前, 也可直接输入版本号):", "cyan"))
    try:
        if stype == "fabric":
            loaders = http_json(FABRIC_META.format(mc=mc_ver))
            vers = [x["loader"]["version"] for x in loaders
                    if x["loader"].get("stable")]
        else:
            meta_url = NEOFORGE_META if stype == "neoforge" else FORGE_META
            meta = http_get(meta_url, 60)
            versions = re.findall(r"<version>([^<]+)</version>", meta)
            if stype == "neoforge":
                # 版本号 = MC 版本去掉开头 "1." (21.1.249 → MC 1.21.1)
                ver_key = mc_ver[2:] if mc_ver.startswith("1.") else mc_ver
                vers = [v for v in versions
                        if re.match(rf"^{re.escape(ver_key)}\.\d+$", v)
                        and not re.search(r"beta|alpha|rc", v, re.I)]
            else:  # Forge 带 MC 前缀: 1.21.1-52.1.16
                vers = [v for v in versions
                        if v.startswith(mc_ver + "-")
                        and not re.search(r"beta|alpha|rc", v, re.I)]
    except Exception as e:
        print(c(f"  获取版本列表失败({e}), 将自动使用最新版", "yellow"))
        return None
    if not vers:
        print(c(f"  {stype} 没有 {mc_ver} 的版本", "yellow"))
        return None
    vers.reverse()  # 最新在前
    show = vers[:10]
    for i, v in enumerate(show):
        mark = c("(默认)", "green") if i == 0 else ""
        print(f"    {i+1}. {v} {mark}")
    while True:
        ans = ask("  选择", "1")
        quit_ans(ans)
        if ans.isdigit() and 1 <= int(ans) <= len(show):
            return show[int(ans) - 1]
        if ans in vers:
            return ans
        print(c("  无效, 请输入序号或版本号", "red"))


def get_fabric_server_jar(mc_ver, server_dir, java_bin, loader=None):
    """Fabric: 官方安装器 server 模式, 生成 fabric-server-launch.jar + 依赖库"""
    try:
        loaders = http_json(FABRIC_META.format(mc=mc_ver))
        meta = http_get("https://maven.fabricmc.net/net/fabricmc/fabric-installer/maven-metadata.xml", 60)
    except Exception as e:
        print(c(f"  获取 Fabric 信息失败: {e}", "red"))
        return False
    if not loaders:
        print(c(f"  Fabric 没有 {mc_ver} 的 loader 版本", "yellow"))
        return False
    if not loader:
        loader = next((x["loader"]["version"] for x in loaders
                       if x["loader"].get("stable")), loaders[0]["loader"]["version"])
    iv = re.search(r"<release>([^<]+)</release>", meta)
    if not iv:
        return False
    iv = iv.group(1)
    path = f"net/fabricmc/fabric-installer/{iv}/fabric-installer-{iv}.jar"
    urls = [f"https://maven.fabricmc.net/{path}",
            f"https://bmclapi2.bangbang93.com/maven/{path}"]
    installer = os.path.join(server_dir, "fabric-installer.jar")
    print(f"  下载 Fabric 安装器 {iv} (loader {loader})...")
    if not fetch(urls, installer):
        return False
    print(f"  运行安装器 (server 模式, 下载依赖库, 稍等)...")
    try:
        subprocess.run([java_bin, "-jar", installer, "server",
                        "-mcversion", mc_ver, "-loader", loader,
                        "-downloadMinecraft", "-noprofile"],
                       cwd=server_dir, check=True)
    except subprocess.CalledProcessError as e:
        print(c(f"  安装器失败: {e}", "red"))
        return False
    return True


def get_mod_installer(mc_ver, stype, server_dir, java, mod_ver=None):
    """NeoForge/Forge: 下载安装器并 --installServer, 返回 True/False"""
    if stype == "neoforge":
        meta_url, mvn = NEOFORGE_META, "https://maven.neoforged.net/releases"
        group = "net/neoforged/neoforge"
    else:
        meta_url, mvn = FORGE_META, "https://maven.minecraftforge.net"
        group = "net/minecraftforge/forge"
    if not mod_ver:
        try:
            meta = http_get(meta_url, 60)
            versions = re.findall(r"<version>([^<]+)</version>", meta)
        except Exception as e:
            print(c(f"  获取版本列表失败: {e}", "red"))
            return False
        # 匹配该 MC 版本的正式版, 排除 beta/alpha/rc
        if stype == "neoforge":
            # NeoForge 版本号 = MC 版本去掉开头 "1." (21.1.249 → MC 1.21.1)
            ver_key = mc_ver[2:] if mc_ver.startswith("1.") else mc_ver
            cands = [v for v in versions
                     if re.match(rf"^{re.escape(ver_key)}\.\d+$", v)
                     and not re.search(r"beta|alpha|rc", v, re.I)]
        else:  # Forge: 1.21.1-52.1.16 带 MC 前缀
            cands = [v for v in versions
                     if v.startswith(mc_ver + "-")
                     and not re.search(r"beta|alpha|rc", v, re.I)]
        if not cands:
            print(c(f"  {stype} 没有 {mc_ver} 的版本", "yellow"))
            return False
        mod_ver = cands[-1]  # 最新正式版
    path = f"{group}/{mod_ver}/{stype}-{mod_ver}-installer.jar"
    urls = [f"{mvn}/{path}",   # 官方仓库
            f"https://bmclapi2.bangbang93.com/maven/{path}"]  # 国内镜像
    installer = os.path.join(server_dir, f"{stype}-installer.jar")
    print(f"  下载 {stype} {mod_ver} 安装器...")
    if not fetch(urls, installer):
        return False
    print(f"  运行安装器 (--installServer, 需下载依赖库, 稍等)...")
    try:
        subprocess.run([java, "-jar", installer, "--installServer"],
                       cwd=server_dir, check=True)
    except subprocess.CalledProcessError as e:
        print(c(f"  安装器失败: {e}", "red"))
        return False
    return True


def reuse_libraries(server_dir):
    """复用本机其他服务器目录已有的依赖库 libraries/ (加速安装, 不走网络)"""
    target = os.path.join(server_dir, "libraries")
    if os.path.isdir(target) and os.listdir(target):
        return
    home = os.path.expanduser("~")
    try:
        entries = os.listdir(home)
    except OSError:
        return
    for entry in entries:
        src = os.path.join(home, entry, "libraries")
        if not os.path.isdir(src):
            continue
        if os.path.realpath(src) == os.path.realpath(target):
            continue
        if not os.listdir(src):
            continue
        print(c(f"  复用本机依赖库: {src} → 本地复制(不走网络)", "green"))
        try:
            shutil.copytree(src, target, dirs_exist_ok=True)
        except OSError:
            continue
        return


def start_mod_server(server_dir, cfg, ram):
    """forge/neoforge: 改写内存参数, 用安装器生成的 run.sh/run.bat 启动"""
    # user_jvm_args.txt 里替换内存参数
    uj = os.path.join(server_dir, "user_jvm_args.txt")
    if os.path.exists(uj):
        with open(uj) as f:
            lines = f.read().splitlines()
        out = []
        wrote = False
        for ln in lines:
            if ln.strip().startswith("-Xm"):
                if not wrote:
                    out.append(f"-Xms512M -Xmx{ram}")
                    wrote = True
                continue
            out.append(ln)
        if not wrote:
            out.append(f"-Xms512M -Xmx{ram}")
        with open(uj, "w") as f:
            f.write("\n".join(out) + "\n")
    if IS_WIN:
        run = os.path.join(server_dir, "run.bat")
        return ["cmd", "/c", "run.bat", "nogui"]
    run = os.path.join(server_dir, "run.sh")
    # exec 链: bash → run.sh → java, 减少包装进程
    return ["bash", "-c", f"exec ./run.sh nogui"]


def get_version_info(version):
    """拉取版本详情 json (含 downloads/javaVersion), 内存缓存"""
    if version in _VERSION_INFO_CACHE:
        return _VERSION_INFO_CACHE[version]
    info = {}
    try:
        req = urllib.request.Request(BMCL_VERSION.format(vid=version),
                                     headers={"User-Agent": APP})
        with urllib.request.urlopen(req, timeout=20) as r:
            info = json.loads(r.read().decode())
    except Exception:
        pass
    _VERSION_INFO_CACHE[version] = info
    return info


def get_server_jar(version, dest, info=None):
    """下载对应版本的官方服务端, 优先 BMCLAPI 镜像, 失败回退 Mojang"""
    if info is None:
        info = get_version_info(version)
    sha1 = info.get("downloads", {}).get("server", {}).get("sha1")
    size = info.get("downloads", {}).get("server", {}).get("size")
    url = info.get("downloads", {}).get("server", {}).get("url") or ""
    # 已存在且大小一致就复用
    if os.path.exists(dest) and size and os.path.getsize(dest) == size:
        print(c(f"  server.jar 已存在, 跳过下载", "green"))
        return True
    print(f"  下载 {c(version, 'cyan')} 服务端核心...")
    if fetch(BMCL_SERVER_JAR.format(vid=version), dest, sha1, size):
        return True
    if url and url != BMCL_SERVER_JAR.format(vid=version):
        print(c("  镜像失败, 尝试官方源...", "yellow"))
        return fetch(url, dest, sha1, size)
    return False


# ---------- 服务器运行状态 ----------

def runtime_dir(server_dir):
    return os.path.join(server_dir, RUNTIME_DIR)


def load_cfg(server_dir):
    try:
        with open(os.path.join(runtime_dir(server_dir), "config.json")) as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def save_cfg(server_dir, cfg):
    os.makedirs(runtime_dir(server_dir), exist_ok=True)
    with open(os.path.join(runtime_dir(server_dir), "config.json"), "w") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def read_pid(server_dir):
    try:
        with open(os.path.join(runtime_dir(server_dir), "pid.json")) as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def is_running(pid):
    """进程存活检测 (Windows 上 os.kill(pid,0) 会误杀进程, 必须用 API)"""
    if IS_WIN:
        try:
            import ctypes
            h = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
            if not h:
                return False
            code = ctypes.c_ulong()
            alive = (ctypes.windll.kernel32.GetExitCodeProcess(
                h, ctypes.byref(code)) and code.value == 259)  # STILL_ACTIVE
            ctypes.windll.kernel32.CloseHandle(h)
            return bool(alive)
        except Exception:
            return False
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def free_port():
    """获取一个随机的本地空闲端口"""
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def send_console(server_dir, line, timeout=10):
    """通过 keeper 的本地 TCP 端口向服务器控制台发送命令"""
    info = read_pid(server_dir)
    if not info or not info.get("console_port"):
        return False
    try:
        s = socket.create_connection(("127.0.0.1", info["console_port"]), timeout)
        s.sendall((line + "\n").encode())
        s.close()
        return True
    except OSError:
        return False


def attach_console(server_dir):
    """接入服务器控制台: 全部启动日志 + 实时输出 + 命令直发, exit/Ctrl+C 退出"""
    rt = runtime_dir(server_dir)
    logs = [os.path.join(rt, "console.log"),        # 进程 stdout/stderr (即时)
            os.path.join(server_dir, "logs", "latest.log")]  # log4j 完整日志
    pos = {lg: 0 for lg in logs}
    # 先把已有日志全部显示出来 (从本次启动开始)
    for lg in logs:
        if os.path.exists(lg):
            with open(lg, errors="ignore") as f:
                sys.stdout.write(f.read())
            pos[lg] = os.path.getsize(lg)
    sys.stdout.flush()
    print(c("已接入控制台: 直接输入命令执行, exit 或 Ctrl+C 退出(服务器继续运行)",
            "green"))
    def flush_logs():
        for lg in logs:
            if not os.path.exists(lg):
                continue
            size = os.path.getsize(lg)
            if size < pos[lg]:  # log4j 轮转后大小重置, 从头读
                pos[lg] = 0
            if size > pos[lg]:
                with open(lg, errors="ignore") as f:
                    f.seek(pos[lg])
                    sys.stdout.write(f.read())
                sys.stdout.flush()
                pos[lg] = size

    sent_stop = False
    try:
        while True:
            flush_logs()
            if select.select([sys.stdin], [], [], 0.2)[0]:
                line = sys.stdin.readline()
                if not line:
                    break  # stdin EOF
                line = line.strip()
                if not line:
                    continue
                if line.lower() in ("exit", "quit"):
                    break
                if line.lower() == "stop":
                    # 关服: 发送后立即退出回 shell, 后台收尾进程负责等退出+清理
                    if send_console(server_dir, line):
                        sent_stop = True
                        flags = {"start_new_session": True} if not IS_WIN else {}
                        subprocess.Popen(
                            [sys.executable, "-c", CLEANUP_CODE, server_dir],
                            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL, **flags)
                        print(c("已发送关服命令, 服务器在后台保存退出, 回 shell...",
                                "yellow"))
                        break
                    print(c("命令发送失败(控制台通道不可用), 请用: "
                            f"1b1t stop {server_dir}", "red"))
                    continue
                send_console(server_dir, line)
            # 服务器停了 → 刷完剩余日志自动退出并清理 pid
            info = read_pid(server_dir)
            if not info or not is_running(info["pid"]):
                flush_logs()
                try:
                    os.remove(os.path.join(runtime_dir(server_dir), "pid.json"))
                except OSError:
                    pass
                print(c("服务器已停止, 退出控制台", "yellow"))
                break
    except KeyboardInterrupt:
        print()
        print(c("已退出控制台(服务器仍在运行)", "yellow"))
        return
    if not sent_stop:
        info = read_pid(server_dir)
        if info and is_running(info["pid"]):
            print(c("已退出控制台(服务器仍在运行)", "yellow"))


def wait_ready(server_dir, timeout=180):
    """等待服务器启动完成(日志出现 Done)"""
    log = os.path.join(server_dir, "logs", "latest.log")
    deadline = time.time() + timeout
    seen = 0
    while time.time() < deadline:
        if os.path.exists(log):
            size = os.path.getsize(log)
            if size > seen:
                with open(log, "r", errors="ignore") as f:
                    f.seek(seen)
                    text = f.read()
                seen = size
                if "Done (" in text:
                    return True
        time.sleep(0.5)
    return False


# ---------- 自主排查 ----------

# (日志特征, 问题, 修复建议)
LOG_PATTERNS = [
    ("Failed to bind to port", "日志显示端口绑定失败", "更换端口后重启"),
    ("already in use", "日志显示端口被占用", "更换端口后重启"),
    ("UnsupportedClassVersionError", "Java 版本不匹配", "安装匹配的 JDK 后重试"),
    ("Unsupported major.minor version", "Java 版本过低", "安装匹配的 JDK 后重试"),
    ("You need to agree to the EULA", "未同意 EULA", "把 eula.txt 改为 eula=true"),
    ("OutOfMemoryError", "内存不足崩溃", "调大内存上限(开服参数)或释放内存"),
    ("Invalid or corrupt jarfile", "server.jar 损坏", "删除 server.jar 重新开服"),
    ("No space left on device", "磁盘已满", "清理磁盘后重启"),
    ("A problem occurred running the Server", "服务器启动报错", "查看上方日志的完整错误输出"),
]


def parse_ram(ram):
    """'2G'/'1024M'/'2'(纯数字按G) → MB"""
    m = re.match(r"(\d+)([GM]?)", str(ram).upper())
    if not m:
        return None
    n = int(m.group(1))
    return n * 1024 if m.group(2) in ("G", "") else n


def total_mem_mb():
    """整机总内存 MB (Linux/Windows/macOS), 失败返回 None"""
    try:
        if os.path.exists("/proc/meminfo"):  # Linux
            with open("/proc/meminfo") as f:
                m = re.search(r"MemTotal:\s+(\d+)", f.read())
            return int(m.group(1)) // 1024 if m else None
        if IS_WIN:  # Windows
            import ctypes
            n = ctypes.c_ulonglong(0)
            ctypes.windll.kernel32.GetPhysicallyInstalledSystemMemory(
                ctypes.byref(n))
            return int(n.value) // 1024
        if sys.platform == "darwin":  # macOS
            out = subprocess.run(["sysctl", "-n", "hw.memsize"],
                                 capture_output=True, text=True,
                                 timeout=10).stdout.strip()
            return int(out) // 1048576
    except Exception:
        pass
    return None


def avail_mem_mb():
    """可用内存 MB (Linux/Windows/macOS), 失败返回 None"""
    try:
        if os.path.exists("/proc/meminfo"):  # Linux
            with open("/proc/meminfo") as f:
                m = re.search(r"MemAvailable:\s+(\d+)", f.read())
            return int(m.group(1)) // 1024 if m else None
        if IS_WIN:  # Windows: GlobalMemoryStatusEx
            import ctypes

            class MSX(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong),
                            ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong),
                            ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong),
                            ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong),
                            ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = MSX()
            m.dwLength = ctypes.sizeof(m)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return m.ullAvailPhys // 1048576
        if sys.platform == "darwin":  # macOS: vm.page_free_count
            free = int(subprocess.run(["sysctl", "-n", "vm.page_free_count"],
                                      capture_output=True, text=True,
                                      timeout=10).stdout.strip())
            pagesz = int(subprocess.run(["sysctl", "-n", "vm.pagesize"],
                                        capture_output=True, text=True,
                                        timeout=10).stdout.strip())
            return free * pagesz // 1048576
    except Exception:
        pass
    return None


def diagnose(server_dir, cfg=None):
    """自主排查: 检查 Java/端口/jar/EULA/磁盘/权限/内存/日志, 返回问题数"""
    print(f"\n{c('=== 自主排查 ===', 'bold')}")
    issues = 0

    def ok(msg):
        print(f"  {c('✓', 'green')} {msg}")

    def bad(msg, fix):
        nonlocal issues
        issues += 1
        print(f"  {c('✗', 'red')} {msg}\n      {c('→ ' + fix, 'yellow')}")

    def warn(msg, fix):
        print(f"  {c('!', 'yellow')} {msg}\n      {c('→ ' + fix, 'yellow')}")

    # 1. Java
    if cfg and cfg.get("version"):
        need = java_major_for(cfg["version"])
        javas = detect_javas()
        if need in javas:
            ok(f"Java {need} 已安装: {javas[need][0]}")
        else:
            got = "、".join(f"Java{k}" for k in sorted(javas)) or "无"
            bad(f"MC {cfg['version']} 需要 Java {need}, 本机只有 {got}",
                java_install_hint(need))

    # 2. 端口
    if cfg and cfg.get("port"):
        port = int(cfg["port"])
        s = socket.socket()
        try:
            s.bind(("0.0.0.0", port))
            s.close()
            ok(f"端口 {port} 空闲")
        except OSError as e:
            bad(f"端口 {port} 被占用",
                f"更换端口, 或停掉占用进程: ss -tlnp | grep {port}")

    # 3. server.jar
    jar = os.path.join(server_dir, "server.jar")
    if os.path.exists(jar) and os.path.getsize(jar) > 0:
        ok("server.jar 存在")
    elif os.path.exists(jar):
        bad("server.jar 是空文件(0 字节)", "删除 server.jar 后重新开服自动下载")
    else:
        warn("server.jar 不存在", "开服时会自动从 BMCLAPI 镜像下载")

    # 4. EULA
    eula_path = os.path.join(server_dir, "eula.txt")
    if os.path.exists(eula_path):
        with open(eula_path, errors="ignore") as f:
            if "eula=true" in f.read():
                ok("已同意 EULA")
            else:
                bad("未同意 EULA", "把 eula.txt 里的 eula 改为 true")
    else:
        warn("没有 eula.txt", "开服时会自动生成(默认同意)")

    # 5. 磁盘空间
    du = shutil.disk_usage(server_dir)
    if du.free > 1 << 30:
        ok(f"磁盘剩余 {du.free >> 30} GB")
    elif du.free > 200 << 20:
        warn(f"磁盘仅剩 {du.free >> 20} MB", "注意清理, 世界存档会持续增长")
    else:
        bad(f"磁盘空间不足 ({du.free >> 20} MB)", "清理磁盘后再开服")

    # 6. 目录权限
    if os.access(server_dir, os.W_OK):
        ok("服务器目录可写")
    else:
        bad("服务器目录不可写", f"chmod u+w {server_dir}")

    # 7. 内存
    avail_mb = avail_mem_mb()
    if avail_mb:
        if cfg and cfg.get("ram"):
            want = parse_ram(cfg["ram"])
            if want and want > avail_mb:
                bad(f"内存不足: 配置 {cfg['ram']} > 可用 {avail_mb}M",
                    "调小内存上限, 或释放内存后重试")
            else:
                ok(f"内存可用 {avail_mb}M (配置 {cfg.get('ram', '-')})")

    # 8. 日志错误分析
    rt = runtime_dir(server_dir)
    for log in (os.path.join(server_dir, "logs", "latest.log"),
                os.path.join(rt, "console.log")):
        if not os.path.exists(log):
            continue
        with open(log, errors="ignore") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - 8192))
            tail = f.read()
        hit = None
        for pattern, msg, fix in LOG_PATTERNS:
            if pattern in tail:
                hit = (msg, fix)
                break
        if hit:
            bad(hit[0], hit[1])
        else:
            ok("日志无已知错误特征")
        break

    print(c("=== 排查结束 ===\n", "bold"))
    return issues


# ---------- 开服 ----------

def start_server(server_dir, cfg, wait=True):
    """按配置启动服务器, 返回 Popen (Linux/Windows/macOS 通用)"""
    os.makedirs(os.path.join(server_dir, "logs"), exist_ok=True)
    rt = runtime_dir(server_dir)
    os.makedirs(rt, exist_ok=True)

    java = pick_java(cfg["version"], cfg.get("java"))
    ram = cfg.get("ram", "2G")
    # wb: 每次启动清空, console.log 只含本次进程输出(attach 时从头全显示)
    console_log = open(os.path.join(rt, "console.log"), "wb")

    flags = {}
    if IS_WIN:
        flags["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
    else:
        flags["start_new_session"] = True
    stype = cfg.get("server_type", "vanilla")
    if stype == "fabric":
        cmd = [java, "-Xms512M", f"-Xmx{ram}", "-jar",
               "fabric-server-launch.jar", "nogui"]
    elif stype in ("neoforge", "forge"):
        cmd = start_mod_server(server_dir, cfg, ram)
    else:
        cmd = [java, "-Xms512M", f"-Xmx{ram}", "-jar", "server.jar", "nogui"]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=console_log,
                         stderr=subprocess.STDOUT, cwd=server_dir, **flags)
    console_log.close()
    # keeper: 持有 java stdin 写端 + 监听本地 TCP 转发控制台命令
    port = free_port()
    keeper = subprocess.Popen(
        [sys.executable, "-c", KEEPER_CODE, str(port)],
        stdin=p.stdin, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        **flags)
    p.stdin.close()  # 写端只由 keeper 持有, java 永远不会读到 EOF
    time.sleep(1)
    if p.poll() is not None:
        keeper.terminate()
        print(c(f"[错误] 服务器进程启动失败(退出码 {p.returncode}), "
                f"详见 {rt}/console.log", "red"))
        diagnose(server_dir, cfg)
        sys.exit(1)
    with open(os.path.join(rt, "pid.json"), "w") as f:
        json.dump({"pid": p.pid, "keeper": keeper.pid, "console_port": port,
                   "start": int(time.time())}, f)
    save_cfg(server_dir, cfg)
    return p


def do_start(server_dir, dry_run=False, advanced=False):
    """start: 有配置直接开, 无配置走向导 (server_dir=None 时向导里选位置)"""
    cfg = load_cfg(server_dir) if server_dir else None
    if cfg is None:
        cfg = wizard(server_dir, advanced=advanced)
        server_dir = cfg.pop("dir")
    else:
        print(c(f"已找到配置: MC {cfg['version']} 端口 {cfg['port']} "
                f"内存 {cfg.get('ram','2G')}", "cyan"))

    # 检查是否已在运行
    old = read_pid(server_dir)
    if old and is_running(old["pid"]):
        sys.exit(c(f"[错误] 服务器已在运行 (PID {old['pid']})", "red"))

    # 版本详情: 用官方 javaVersion 字段精确匹配 Java
    info = get_version_info(cfg["version"])
    java_major = info.get("javaVersion", {}).get("majorVersion")
    if java_major:
        cfg["java"] = java_major

    # 写 eula + 配置
    with open(os.path.join(server_dir, "eula.txt"), "w") as f:
        f.write("# 继续使用即代表您同意 Minecraft EULA\n"
                "# https://aka.ms/MinecraftEULA\neula=true\n")
    with open(os.path.join(server_dir, "server.properties"), "w") as f:
        f.write(render_properties(cfg["props"]))
    save_cfg(server_dir, cfg)
    if dry_run:
        print(c("dry-run: 配置文件已生成, 未下载/未启动", "yellow"))
        return

    # 先确认 Java 匹配, 再下载
    java_bin = pick_java(cfg["version"], cfg.get("java"))

    # 按类型准备服务端
    stype = cfg.get("server_type", "vanilla")
    if stype == "fabric":
        jar = os.path.join(server_dir, "fabric-server-launch.jar")
        if not os.path.exists(jar) or os.path.getsize(jar) < 1000:
            if not get_fabric_server_jar(cfg["version"], server_dir, java_bin,
                                         cfg.get("mod_version")):
                sys.exit(c("[错误] Fabric 安装失败", "red"))
    elif stype in ("neoforge", "forge"):
        if not os.path.exists(os.path.join(server_dir, "run.sh")) and \
           not os.path.exists(os.path.join(server_dir, "run.bat")):
            reuse_libraries(server_dir)  # 复用本机已有依赖库, 加速安装
            if not get_mod_installer(cfg["version"], stype, server_dir,
                                     java_bin, cfg.get("mod_version")):
                sys.exit(c(f"[错误] {stype} 安装失败", "red"))
    else:
        jar = os.path.join(server_dir, "server.jar")
        if not get_server_jar(cfg["version"], jar, info):
            sys.exit(c("[错误] 服务端下载失败", "red"))

    print(c(f"\n正在启动: MC {cfg['version']} 端口 {cfg['port']} "
            f"内存 {cfg.get('ram','2G')}", "bold"))
    p = start_server(server_dir, cfg)
    print(c(f"  已启动! PID {p.pid}", "green"))
    print(f"  日志: {server_dir}/logs/latest.log")

    # 等服务器就绪后注入 gamerule (如死亡不掉落)
    if cfg.get("gamerules"):
        print(f"  等待服务器就绪...")
        if wait_ready(server_dir):
            for rule, val in cfg["gamerules"].items():
                send_console(server_dir, f"gamerule {rule} {val}")
            print(c(f"  已设置游戏规则: " + ", ".join(
                f"{k}={v}" for k, v in cfg["gamerules"].items()), "green"))
        else:
            print(c("  等待就绪超时, 游戏规则未注入(可用 console 命令手动设置)", "yellow"))
            diagnose(server_dir, cfg)
    print(c(f"\n完成! 关服: 1b1t-open-server stop {server_dir}", "green"))
    # 交互终端下自动接入控制台 (管道/脚本则跳过)
    if sys.stdin.isatty():
        attach_console(server_dir)


def do_stop(server_dir):
    old = read_pid(server_dir)
    if not old or not is_running(old["pid"]):
        print(c("服务器未在运行", "yellow"))
        return 0
    print(f"发送 stop 命令 (PID {old['pid']})...")
    if send_console(server_dir, "stop"):
        deadline = time.time() + 60
        while is_running(old["pid"]) and time.time() < deadline:
            time.sleep(1)
    if is_running(old["pid"]):
        print(c("优雅关闭超时, 结束进程...", "yellow"))
        try:
            if IS_WIN:
                import signal as _sig
                os.kill(old["pid"], _sig.SIGTERM)  # Windows 上即 TerminateProcess
            else:
                os.killpg(old["pid"], 15)  # 杀整个进程组(含 run.sh 包装)
        except (OSError, ImportError):
            pass
        time.sleep(10)
    if is_running(old["pid"]):
        print(c("强制结束进程", "red"))
        try:
            if IS_WIN:
                import signal as _sig
                os.kill(old["pid"], _sig.SIGTERM)  # Windows 上即 TerminateProcess
            else:
                os.killpg(old["pid"], 9)  # SIGKILL 整个进程组, 不残留孤儿
        except (OSError, ImportError):
            pass
    keeper = old.get("keeper")
    if keeper and is_running(keeper):
        try:
            import signal as _sig
            os.kill(keeper, _sig.SIGTERM)
            for _ in range(10):
                time.sleep(0.5)
                if not is_running(keeper):
                    break
            if is_running(keeper):
                os.kill(keeper, _sig.SIGTERM)  # Windows 上即 TerminateProcess
        except (OSError, ImportError):
            pass
    try:
        os.remove(os.path.join(runtime_dir(server_dir), "pid.json"))
    except OSError:
        pass
    print(c("已停止", "green"))


def do_kill(server_dir):
    """强制杀死服务器进程(不保存, 仅 stop 卡死时用)"""
    old = read_pid(server_dir)
    if not old or not is_running(old["pid"]):
        print(c("服务器未在运行", "yellow"))
        return 0
    print(c(f"强制杀死进程 PID {old['pid']} (不会保存世界!)", "red"))
    try:
        if IS_WIN:
            import signal as _sig
            os.kill(old["pid"], _sig.SIGTERM)
        else:
            os.kill(old["pid"], 9)
    except OSError:
        pass
    keeper = old.get("keeper")
    if keeper and is_running(keeper):
        try:
            import signal as _sig
            os.kill(keeper, _sig.SIGTERM)
        except OSError:
            pass
    try:
        os.remove(os.path.join(runtime_dir(server_dir), "pid.json"))
    except OSError:
        pass
    print(c("已杀死", "green"))


def do_status(server_dir):
    old = read_pid(server_dir)
    cfg = load_cfg(server_dir)
    if not old or not is_running(old["pid"]):
        print(c("状态: 未运行", "yellow"))
        if cfg:
            print(f"配置: MC {cfg['version']} 端口 {cfg['port']} "
                  f"内存 {cfg.get('ram','2G')}")
        return 0
    uptime = int(time.time()) - old.get("start", 0)
    print(c("状态: 运行中", "green"))
    print(f"  PID: {old['pid']}  已运行: {uptime//3600}h{uptime%3600//60}m")
    if cfg:
        print(f"  MC: {cfg['version']}  端口: {cfg['port']}  内存: {cfg.get('ram','2G')}")
        try:
            s = socket.create_connection(("127.0.0.1", int(cfg["port"])), 2)
            s.close()
            print(c("  端口监听: 正常", "green"))
        except OSError:
            print(c("  端口监听: 未就绪", "yellow"))


# ---------- 向导 ----------

def pick_difficulty():
    """难度选择: 中文表格 + 数字"""
    print(c("  难度(数字选择):", "cyan"))
    print_table([
        ("编号", "难度", "说明"),
        ("1", "和平", "无怪物, 饥饿不减少, 适合纯建筑"),
        ("2", "简单", "怪物弱, 饥饿不掉到10心以下"),
        ("3", "普通", "标准体验(默认)"),
        ("4", "困难", "怪物强, 饥饿可致死, 僵尸破门"),
    ])
    while True:
        ans = ask("  选择", "3")
        quit_ans(ans)
        if ans in ("1", "2", "3", "4"):
            return ("peaceful", "easy", "normal", "hard")[int(ans) - 1]
        if ans.lower() in ("peaceful", "easy", "normal", "hard"):
            return ans.lower()
        print(c("  请输入 1-4 或英文难度名", "red"))


def default_ram():
    """不询问, 直接取空闲内存 70% 内的最大档位"""
    avail = avail_mem_mb()
    cap = int((avail or 2048) * 0.7)
    tiers = [1024, 2048, 4096, 8192, 16384, 32768, 65536]
    opts = [t for t in tiers if t <= cap][-4:] or [1024]
    return f"{opts[-1] // 1024}G"


def pick_ram():
    """内存上限选择: 整机空闲内存 70% 以下的档位, 可自定义"""
    total = total_mem_mb()
    avail = avail_mem_mb()
    cap = int((avail or 2048) * 0.7)  # 上限 = 空闲的70%
    tiers = [1024, 2048, 4096, 8192, 16384, 32768, 65536]
    opts = [t for t in tiers if t <= cap][-4:] or [1024]
    info = ""
    if total and avail:
        info = f"整机{total // 1024}G 空闲{avail // 1024}G"
    print(c(f"  内存上限 {info} (最大建议 = 空闲70%):", "cyan"))
    for i, t in enumerate(opts):
        mark = c("(推荐)", "green") if i == len(opts) - 1 else ""
        print(f"    {i+1}. {t // 1024}G {mark}")
    print(f"    也可以直接输入, 如 4G/512M (纯数字按G算)")
    while True:
        ans = ask("  选择", str(len(opts)))
        quit_ans(ans)
        if ans.isdigit() and 1 <= int(ans) <= len(opts):
            return f"{opts[int(ans) - 1] // 1024}G"
        if re.match(r"^\d+[GM]?$", ans, re.I):
            return ans.upper() + ("G" if not re.search(r"[GM]", ans, re.I) else "")
        print(c("  无效, 请输入序号或如 4G/512M", "red"))


def wizard(server_dir, advanced=False):
    """交互式向导, 返回配置 dict(含 dir 字段)
    简单模式(默认): 只问版本/类型/目录/端口 4 项, 无任何 y/n 询问, 直接开服
    高级模式(--advanced): 逐项询问 11 项配置 + 全项编辑 + 确认"""
    print(c(BANNER, "cyan"))

    ver = pick_version()["id"]
    stype = pick_server_type()
    mod_version = None
    if stype != "vanilla":
        mod_version = pick_mod_version(ver, stype)

    if server_dir is None:
        step(2, "选择服务器位置")
        d = ask("  服务器目录", os.path.expanduser(f"~/1b1t-{ver}"))
        quit_ans(d)
        server_dir = os.path.abspath(d)
    os.makedirs(server_dir, exist_ok=True)
    print(f"  目录: {c(server_dir, 'green')}")
    if os.listdir(server_dir):
        print(c("  注意: 目录非空, 已有文件不会被覆盖(server.properties 除外)", "yellow"))

    step(3, "选择端口")
    while True:
        port = ask("  端口", "25565")
        quit_ans(port)
        if not port.isdigit() or not 1 <= int(port) <= 65535:
            print(c("  端口无效, 请输入 1-65535 (0 退出)", "red"))
            continue
        # 端口占用检测: 被占用自动换空闲端口
        s = socket.socket()
        try:
            s.bind(("0.0.0.0", int(port)))
            s.close()
            break
        except OSError:
            free = free_port()
            print(c(f"  端口 {port} 已被占用(有服务器在跑), 自动改用空闲端口 {free}",
                    "yellow"))
            port = str(free)
            break

    props = {"server-port": port}
    keep = False
    if not advanced:  # 简单: 4 项重要选择后零询问, 用软件设置里的默认值直接开
        st = load_settings()
        props["online-mode"] = st["online_mode"]
        props["motd"] = st["motd"]
        props["difficulty"] = st["difficulty"]
        keep = st["keep_inventory"] == "true"
        ram = default_ram()
        print(c(f"  默认配置: 正版验证{'开' if props['online-mode'] == 'true' else '关'}"
                f" · {props['difficulty']}难度 · 死亡掉落{'开' if keep else '关'}"
                f" · 内存 {ram} (自动)", "cyan"))
    else:  # 高级: 逐项询问 11 项 + 全项编辑 + 确认
        step(4, "配置")
        props["online-mode"] = str(ask_bool("  正版验证", True)).lower()
        props["enable-command-block"] = str(ask_bool("  命令方块", False)).lower()
        keep = ask_bool("  死亡不掉落", False)
        props["motd"] = ask("  MOTD(服务器名)", "1b1t Server")
        props["difficulty"] = pick_difficulty()
        props["max-players"] = ask("  最大玩家数", "20")
        props["view-distance"] = ask("  视距", "10")
        props["white-list"] = str(ask_bool("  白名单", False)).lower()
        props["pvp"] = str(ask_bool("  PVP", True)).lower()
        props["level-seed"] = ask("  种子(空=随机)", "")
        ram = pick_ram()
        advanced_editor(props)

    cfg = {"dir": server_dir, "version": ver, "server_type": stype,
           "mod_version": mod_version, "port": int(port), "ram": ram,
           "props": props, "gamerules": {}}
    if keep:
        cfg["gamerules"]["keepInventory"] = "true"

    type_desc = stype + (f" {mod_version}" if mod_version else "")
    print(f"  类型: {c(type_desc, 'green')}    MC 版本: {c(ver, 'green')}    "
          f"端口: {c(port, 'green')}    内存: {c(ram, 'green')}")
    print(f"  目录: {c(server_dir, 'green')}")
    if advanced:
        if not ask_bool("  确认开服?", True):
            sys.exit("已取消")
    return cfg


# ---------- 入口 ----------

def _mirror_download(job):
    """并发下载任务: (描述, [urls], 镜像目标路径) → 结果描述或 None"""
    desc, urls, mp = job
    if os.path.exists(mp) and os.path.getsize(mp) > 0:
        return None  # 已缓存
    os.makedirs(os.path.dirname(mp), exist_ok=True)
    tmp = mp + ".part"
    for attempt in range(3):  # 限流/抖动时重试
        if os.path.exists(tmp):
            os.remove(tmp)
        for u in urls:
            if _fetch_one(u, tmp, quiet=True):
                os.replace(tmp, mp)
                return desc
        # 404 = 源上不存在(旧版本已被清理), 重试无意义, 直接放弃
        try:
            req = urllib.request.Request(urls[0], method="HEAD",
                                         headers={"User-Agent": APP})
            urllib.request.urlopen(req, timeout=20)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                break
        except Exception:
            pass
        time.sleep(5)
    try:
        os.remove(tmp)
    except OSError:
        pass
    return f"失败: {desc}"


def do_mirror(versions):
    """预取安装包到镜像目录 (serverdown 直接可见)
    无参数 = 全部正式版 vanilla + 全部 NeoForge/Forge 安装器 + Fabric 安装器"""
    from concurrent.futures import ThreadPoolExecutor
    print(c(f"镜像目录: {mirror_dir()}", "cyan"))
    releases = [v["id"] for v in load_manifest(force=True)
                if v["type"] == "release"]
    if versions:
        releases = versions
        print(f"  预取版本: {', '.join(releases)}")
    else:
        print(f"  全量预取: {len(releases)} 个正式版 + 全部 mod 安装器")
    jobs = []
    # 1. vanilla 服务端 (BMCLAPI 优先, 官方 piston 回退)
    for mc in releases:
        u = BMCL_SERVER_JAR.format(vid=mc)
        urls = [u]
        try:
            off = get_version_info(mc).get("downloads", {}).get("server", {}).get("url")
            if off:
                urls.append(off)
        except Exception:
            pass
        jobs.append((f"vanilla {mc}", urls, _mirror_path(u)))
    # 2. mod 安装器
    for stype, meta_url, mvn, group in (
            ("neoforge", NEOFORGE_META, "https://maven.neoforged.net/releases",
             "net/neoforged/neoforge"),
            ("forge", FORGE_META, "https://maven.minecraftforge.net",
             "net/minecraftforge/forge")):
        try:
            meta = http_get(meta_url, 60)
            vers = [v for v in re.findall(r"<version>([^<]+)</version>", meta)
                    if not re.search(r"beta|alpha|rc", v, re.I)]
        except Exception as e:
            print(c(f"  {stype} 版本列表获取失败: {e}", "yellow"))
            continue
        if versions:  # 指定版本时只取该 MC 版本对应的安装器
            if stype == "neoforge":
                keys = [v[2:] for v in versions if v.startswith("1.")]
                vers = [v for v in vers
                        if any(re.match(rf"^{re.escape(k)}\.\d+$", v) for k in keys)]
            else:
                vers = [v for v in vers
                        if any(v.startswith(mc + "-") for mc in versions)]
        for v in vers:
            path = f"{group}/{v}/{stype}-{v}-installer.jar"
            u = f"{mvn}/{path}"
            jobs.append((f"{stype} {v}", [u, f"https://bmclapi2.bangbang93.com/maven/{path}"],
                         _mirror_path(u)))
    # 3. Fabric 安装器 (最新一个即可, 支持任意 loader 版本)
    try:
        meta = http_get("https://maven.fabricmc.net/net/fabricmc/fabric-installer/maven-metadata.xml", 60)
        iv = re.search(r"<release>([^<]+)</release>", meta).group(1)
        path = f"net/fabricmc/fabric-installer/{iv}/fabric-installer-{iv}.jar"
        u = f"https://maven.fabricmc.net/{path}"
        jobs.append(("fabric-installer " + iv, [u, f"https://bmclapi2.bangbang93.com/maven/{path}"],
                     _mirror_path(u)))
    except Exception as e:
        print(c(f"  fabric 列表获取失败: {e}", "yellow"))

    print(f"  共 {len(jobs)} 个文件, 30 线程并发下载...")
    done = 0
    failed = []
    with ThreadPoolExecutor(max_workers=30) as ex:
        for r in ex.map(_mirror_download, jobs):
            done += 1
            if r:
                failed.append(r)
            if done % 10 == 0 or done == len(jobs):
                print(f"\r  进度: {done}/{len(jobs)}", end="", flush=True)
    print()
    if failed:
        print(c(f"  失败 {len(failed)} 个: {', '.join(failed[:8])}{'...' if len(failed) > 8 else ''}",
                "red"))
    print(c(f"\n完成! 镜像已在 serverdown 可见: {mirror_http()}", "green"))


def do_config(server_dir):
    """修改服务器设置: 编辑已有服务器的 server.properties 全部项"""
    cfg = load_cfg(server_dir)
    if not cfg:
        sys.exit(c(f"[错误] 没有找到配置: {server_dir}", "red"))
    print(c(f"编辑服务器配置: {server_dir}", "cyan"))
    props = dict(cfg["props"])
    advanced_editor(props)
    cfg["props"] = props
    save_cfg(server_dir, cfg)
    with open(os.path.join(server_dir, "server.properties"), "w") as f:
        f.write(render_properties(props))
    print(c("已保存 server.properties", "green"))
    old = read_pid(server_dir)
    if old and is_running(old["pid"]):
        print(c(f"服务器正在运行, 重启后生效: 1b1t restart {server_dir}", "yellow"))
    return 0


def do_settings():
    """软件设置: 默认配置值 / 镜像目录 / 镜像 HTTP 地址"""
    st = load_settings()
    print(c("[软件设置]", "bold"))
    print(c("  修改后新开服务器(简单模式)会使用这些默认值", "dim"))
    items = [
        ("1", "默认正版验证", st["online_mode"], "true/false"),
        ("2", "默认难度", st["difficulty"], "peaceful/easy/normal/hard"),
        ("3", "默认MOTD", st["motd"], "服务器显示名"),
        ("4", "默认死亡不掉落", st["keep_inventory"], "true/false"),
        ("5", "镜像目录", st.get("mirror_dir") or "(默认 ~/1b1t-mirror)",
         "留空=恢复默认"),
        ("6", "镜像HTTP地址", st.get("mirror_http") or MIRROR_HTTP,
         "其他机器的下载入口"),
    ]
    while True:
        print()
        print_table([("编号", "设置项", "当前值", "说明")] + items)
        print(c("  修改: 输入 '编号 值' (如 2 hard), 输入 0 退出", "yellow"))
        ans = ask("  修改", "")
        if ans in ("", "0"):
            break
        m = re.match(r"(\d)\s+(.*)", ans)
        if not m:
            print(c("  格式: 编号 值, 如: 2 hard; 0 退出", "red"))
            continue
        i = int(m.group(1)) - 1
        if not 0 <= i < len(items):
            print(c("  编号无效", "red"))
            continue
        key = ("online_mode", "difficulty", "motd", "keep_inventory",
               "mirror_dir", "mirror_http")[i]
        val = m.group(2).strip()
        if key in ("online_mode", "keep_inventory"):
            val = str(val.lower() in ("true", "y", "yes", "1")).lower()
        if key == "mirror_dir":
            val = "" if val == "默认" else val
        st[key] = val
        items = [
            ("1", "默认正版验证", st["online_mode"], "true/false"),
            ("2", "默认难度", st["difficulty"], "peaceful/easy/normal/hard"),
            ("3", "默认MOTD", st["motd"], "服务器显示名"),
            ("4", "默认死亡不掉落", st["keep_inventory"], "true/false"),
            ("5", "镜像目录", st.get("mirror_dir") or "(默认 ~/1b1t-mirror)",
             "留空=恢复默认"),
            ("6", "镜像HTTP地址", st.get("mirror_http") or MIRROR_HTTP,
             "其他机器的下载入口"),
        ]
        save_settings(st)
        print(c("已保存", "green"))
    return 0


def find_servers():
    """扫描 ~ 下含 .1b1t-open-server/config.json 的目录"""
    found = []
    seen = set()
    home = os.path.expanduser("~")
    try:
        entries = os.listdir(home)
    except OSError:
        return found
    for entry in entries:
        d = os.path.join(home, entry)
        if not os.path.isdir(d) or entry.startswith("."):
            continue
        if load_cfg(d):
            rp = os.path.realpath(d)
            if rp not in seen:
                seen.add(rp)
                found.append(d)
    return found


def main_menu():
    """无参数时的主菜单: 开服/启动/删除/状态"""
    print(c(BANNER, "cyan"))
    while True:
        servers = find_servers()
        print(c("\n[主菜单]", "bold"))
        print("  1. 开服向导 (新服务器)")
        print("  2. 启动服务器 (已有服务器)")
        print("  3. 删除服务器")
        print("  4. 查看状态")
        print("  5. 修改服务器设置 (server.properties)")
        print("  6. 软件设置")
        print("  7. 强制杀死进程 (不保存世界)")
        print("  0. 退出")
        ans = ask("  选择", "1")
        if ans == "1":
            do_start(None)
            return
        if ans == "0":
            sys.exit(0)
        if ans == "6":
            do_settings()
            continue
        if ans not in ("2", "3", "4", "5", "7"):
            print(c("  无效选择", "red"))
            continue
        if not servers:
            print(c("  没有找到已有服务器 (也可用: 1b1t start <目录>)", "yellow"))
            continue
        print(c("  已有服务器:", "cyan"))
        for i, d in enumerate(servers):
            c0 = load_cfg(d)
            print(f"    {i+1}. {d}  (MC {c0['version']})")
        print("    也可以直接输入目录路径")
        choice = ask("  选择")
        if choice.isdigit() and 1 <= int(choice) <= len(servers):
            d = servers[int(choice) - 1]
        else:
            d = os.path.abspath(os.path.expanduser(choice))
        if ans == "2":
            do_start(d)
            return
        if ans == "3":
            if ask_bool(c(f"  确认删除整个目录 {d}? 不可恢复!", "red"), False):
                # 目录里有服务器在运行则先关闭, 避免删目录后进程变孤儿
                old = read_pid(d)
                if old and is_running(old["pid"]):
                    print(c("  服务器正在运行, 先关闭...", "yellow"))
                    do_stop(d)
                shutil.rmtree(d, ignore_errors=True)
                print(c("已删除", "green"))
            continue
        if ans == "4":
            do_status(d)
            continue
        if ans == "5":
            do_config(d)
            continue
        if ans == "7":
            if ask_bool(c(f"  确认强制杀死 {d}? 不会保存世界!", "red"), False):
                do_kill(d)
            continue


def usage():
    print(f"""用法: {APP} [命令] [参数]

  无参数             主菜单: 开服向导/启动服务器/删除服务器/查看状态
  start              开服向导(选版本→目录→端口→配置, 简单/高级模式)
  start <目录>       按已有配置开服
  stop <目录>        关服(默认当前目录)
  restart <目录>     重启
  status <目录>      查看状态
  doctor <目录>      自主排查问题(开服失败时也会自动运行)
  console <目录> <命令>   向服务器控制台发送命令(如: console ./ say hello)
  kill <目录>          强制杀死服务器进程(不保存世界, stop 卡死时用)
  config <目录>        修改服务器设置(编辑 server.properties 全部项)
  settings             软件设置(默认配置/镜像目录/镜像HTTP地址)
  mirror [版本...]     预取安装包到本地镜像 ~/1b1t-mirror (之后开服不走网络)
  其他: --dry-run 只生成配置, 不下载不启动; 开服后自动接入控制台(exit 退出)
        --advanced 高级向导(逐项询问 11 项配置+全项编辑); 默认简单模式零询问""")


def main():
    args = sys.argv[1:]
    if args and args[0] in ("-h", "--help", "help"):
        usage()
        return 0

    cmd = "start"
    server_dir = None
    dry_run = "--dry-run" in args
    advanced = "--advanced" in args
    args = [a for a in args if a not in ("--dry-run", "--advanced")]
    if args and args[0] in ("start", "stop", "restart", "status", "doctor",
                            "console", "mirror", "config", "settings",
                            "kill"):
        cmd = args.pop(0)
    if cmd == "mirror":
        return do_mirror(args)
    if cmd == "settings":
        return do_settings()
    if args and not args[0].startswith("-"):
        server_dir = os.path.abspath(args.pop(0))
        if cmd == "console" and args:
            return do_console(server_dir, " ".join(args))
    elif cmd == "console":
        sys.exit("console 需要: console <目录> <命令>")

    if cmd == "start" and server_dir is None:
        # 纯 1b1t → 主菜单(开服/启动/删除/状态); 1b1t start → 向导里选位置
        if len(sys.argv) == 1:
            main_menu()
            return 0
        do_start(None, dry_run=dry_run, advanced=advanced)
        return 0

    if server_dir is None:
        server_dir = os.getcwd()

    if cmd == "start":
        do_start(server_dir, dry_run=dry_run, advanced=advanced)
    elif cmd == "stop":
        do_stop(server_dir)
    elif cmd == "restart":
        do_stop(server_dir)
        do_start(server_dir)
    elif cmd == "status":
        do_status(server_dir)
    elif cmd == "doctor":
        do_doctor(server_dir)
    elif cmd == "config":
        do_config(server_dir)
    elif cmd == "kill":
        do_kill(server_dir)
    return 0


def do_doctor(server_dir):
    """手动排查"""
    cfg = load_cfg(server_dir)
    print(f"服务器目录: {c(server_dir, 'cyan')}")
    old = read_pid(server_dir)
    if old and is_running(old["pid"]):
        print(c(f"服务器正在运行 (PID {old['pid']})", "green"))
    issues = diagnose(server_dir, cfg)
    if issues == 0:
        print(c("未发现问题", "green"))
    else:
        print(c(f"发现 {issues} 个问题, 按上方建议修复", "red"))
    return issues


def do_console(server_dir, line):
    if not send_console(server_dir, line):
        sys.exit(c("[错误] 无法连接控制台(服务器未运行?)", "red"))
    print(c(f"已发送: {line}", "green"))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n已取消")
        sys.exit(130)
    except EOFError:
        print("\n已取消")
        sys.exit(130)

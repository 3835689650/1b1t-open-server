@echo off
chcp 65001 >nul
echo ===== 1b1t 一键安装 =====
for /f "delims=" %%i in ('python -c "import sys,os;print(os.path.dirname(sys.executable))"') do set PYDIR=%%i
if not exist "%PYDIR%\Scripts" mkdir "%PYDIR%\Scripts"
copy /y "%~dp01b1t.py" "%PYDIR%\Scripts\1b1t.py" >nul
> "%PYDIR%\Scripts\1b1t.bat" echo @echo off
>> "%PYDIR%\Scripts\1b1t.bat" echo python "%PYDIR%\Scripts\1b1t.py" %%*
echo.
echo 安装完成! 重新打开终端, 输入 1b1t 即可启动
echo (如果提示找不到命令, 请确认 Python 安装时勾选了 Add to PATH)
pause

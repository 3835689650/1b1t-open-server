@echo off
chcp 65001 >nul
python 1b1t.py %*
if errorlevel 1 pause

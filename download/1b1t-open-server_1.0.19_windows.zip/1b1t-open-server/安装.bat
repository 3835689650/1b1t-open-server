@echo off
chcp 65001 >nul
for /f "delims=" %%i in ('python -c "import sys,os;print(os.path.dirname(sys.executable))"') do set PYDIR=%%i
if not exist "%PYDIR%\Scripts" mkdir "%PYDIR%\Scripts"
copy /y "%~dp01b1t.py" "%PYDIR%\Scripts\1b1t.py" >nul
> "%PYDIR%\Scripts\1b1t.bat" echo @echo off
>> "%PYDIR%\Scripts\1b1t.bat" echo python "%PYDIR%\Scripts\1b1t.py" %%*
echo 安装完成! 重新打开终端, 输入 1b1t 启动
pause
